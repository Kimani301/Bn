# Bn (Android app)

Bn wraps the Bn web app (app/src/main/assets/index.html) in an Android app that can
dial USSD codes, send step-by-step replies, and read payment SMS.

## Get the APK (no computer tools needed)
1. Upload everything in this folder to a new GitHub repository (the `.github` folder must come too).
2. Open the repo > **Actions** tab > **Build Bn APK** > wait for the green tick (about 3-5 min).
   (If it did not start, press **Run workflow**.)
3. Open the finished run > **Artifacts** > download **Bn-apk**, unzip it, install `app-debug.apk`.

## First run on the phone
1. Allow Phone, SMS and Notifications when asked. Choose "Don't optimise" for battery.
2. Turn on **Bn** in Settings > Accessibility (needed to read USSD menus and type replies).
   If Android blocks it: Settings > Apps > Bn > top-right menu > **Allow restricted settings**, then retry.
3. The top of the app should say **Connected to phone**.
4. Keep the Bn notification showing; use the Back button (not swipe-away) to leave the app running.

## Updating the app's screens
Edit `app/src/main/assets/index.html` on GitHub and commit. A new APK is built automatically.

## Notes
- Debug build, installs on any phone ("unknown sources" must be allowed).
- Test with a small offer first. USSD pop-ups differ between phone brands; if steps are skipped,
  set Settings > Dialing speed to Careful.
