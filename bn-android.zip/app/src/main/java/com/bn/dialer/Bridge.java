package com.bn.dialer;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.net.Uri;
import android.telecom.PhoneAccountHandle;
import android.telecom.TelecomManager;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import android.telephony.TelephonyManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.List;

/** The "NativeBridge" the Bn web page talks to, plus helpers to push events into the page. */
public class Bridge {
    static final Handler MAIN = new Handler(Looper.getMainLooper());
    static volatile WebView web;
    static volatile boolean ready = false;

    private final Context ctx;

    Bridge(Context c) {
        ctx = c.getApplicationContext();
    }

    static String q(String s) {
        return JSONObject.quote(s == null ? "" : s);
    }

    /** Run JavaScript in the page now. Dropped if the page is not loaded yet. */
    static void js(final String script) {
        MAIN.post(() -> {
            WebView w = web;
            if (ready && w != null) w.evaluateJavascript(script, null);
        });
    }

    /** Payment texts must never be lost: run now, or keep them until the page is loaded. */
    static void sms(final Context c, final String script) {
        final Context app = c.getApplicationContext();
        MAIN.post(() -> {
            WebView w = web;
            if (ready && w != null) w.evaluateJavascript(script, null);
            else store(app, script);
        });
    }

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("bn_queue", Context.MODE_PRIVATE);
    }

    private static synchronized void store(Context c, String script) {
        try {
            SharedPreferences p = prefs(c);
            JSONArray a = new JSONArray(p.getString("q", "[]"));
            a.put(script);
            p.edit().putString("q", a.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    /** Called when the page has loaded: replay anything that arrived while the app was closed. */
    static synchronized void flush(Context c) {
        try {
            SharedPreferences p = prefs(c);
            JSONArray a = new JSONArray(p.getString("q", "[]"));
            p.edit().remove("q").apply();
            for (int i = 0; i < a.length(); i++) {
                final String s = a.getString(i);
                MAIN.postDelayed(() -> {
                    WebView w = web;
                    if (w != null) w.evaluateJavascript(s, null);
                }, 400L + i * 150L);
            }
        } catch (Exception ignored) {
        }
    }

    static void toast(String msg) {
        js("if(window.toast)toast(" + q(msg) + ");if(window.addLog)addLog(" + q(msg) + ")");
    }

    /* ---------------- methods the web page calls ---------------- */

    @JavascriptInterface
    public void dialUssd(final String code, final int simSlot) {
        MAIN.post(() -> {
            try {
                UssdService s = UssdService.inst;
                if (s == null) {
                    toast("Turn on Bn in Accessibility settings, or replies cannot be sent");
                } else {
                    s.resetText();
                }
                Uri uri = Uri.parse("tel:" + Uri.encode(code));
                TelecomManager tm = (TelecomManager) ctx.getSystemService(Context.TELECOM_SERVICE);
                Bundle extras = new Bundle();
                if (simSlot >= 0) {
                    PhoneAccountHandle h = handleFor(simSlot, tm);
                    if (h != null) extras.putParcelable(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, h);
                }
                tm.placeCall(uri, extras);
            } catch (Exception e) {
                toast("Could not dial: " + e.getMessage());
            }
        });
    }

    @JavascriptInterface
    public void replyUssd(final String text) {
        MAIN.post(() -> {
            UssdService s = UssdService.inst;
            if (s == null) toast("Turn on Bn in Accessibility settings to send USSD replies");
            else s.reply(text);
        });
    }

    @JavascriptInterface
    public void endUssd() {
        MAIN.post(() -> {
            UssdService s = UssdService.inst;
            if (s != null) s.dismiss();
        });
    }

    /* ---------------- SIM selection ---------------- */

    private PhoneAccountHandle handleFor(int slot, TelecomManager tm) {
        try {
            SubscriptionManager sm = (SubscriptionManager) ctx.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE);
            TelephonyManager tel = (TelephonyManager) ctx.getSystemService(Context.TELEPHONY_SERVICE);
            SubscriptionInfo si = sm.getActiveSubscriptionInfoForSimSlotIndex(slot);
            List<PhoneAccountHandle> hs = tm.getCallCapablePhoneAccounts();
            if (si != null) {
                for (PhoneAccountHandle h : hs) {
                    if (Build.VERSION.SDK_INT >= 29 && tel.getSubscriptionId(h) == si.getSubscriptionId()) return h;
                    String id = h.getId();
                    if (id != null && (id.equals(String.valueOf(si.getSubscriptionId()))
                            || id.equals(si.getIccId()))) return h;
                }
            }
            if (slot < hs.size()) return hs.get(slot);
        } catch (Exception ignored) {
        }
        return null;
    }
}
