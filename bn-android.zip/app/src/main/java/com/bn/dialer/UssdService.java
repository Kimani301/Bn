package com.bn.dialer;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * Reads the phone's USSD pop-up, passes its text to the Bn page, and types/sends the next reply.
 * It only looks at windows from the phone/telephony system apps.
 */
public class UssdService extends AccessibilityService {
    static volatile UssdService inst;

    private final Handler h = new Handler(Looper.getMainLooper());
    private String lastText = "";
    private long lastAt = 0;

    private static final Pattern SEND_BTN = Pattern.compile("(?i)^(send|reply|ok|okay|submit|yes|continue|accept)$");
    private static final Pattern CLOSE_BTN = Pattern.compile("(?i)^(cancel|dismiss|close|ok|okay|exit|no)$");
    private static final Pattern RUNNING = Pattern.compile("(?i)(ussd code running|please wait|loading)");

    private static class Scan {
        final StringBuilder text = new StringBuilder();
        boolean input = false;
        final List<AccessibilityNodeInfo> buttons = new ArrayList<>();
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        inst = this;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        inst = null;
        return super.onUnbind(intent);
    }

    @Override
    public void onInterrupt() {
    }

    void resetText() {
        lastText = "";
        lastAt = 0;
    }

    private static boolean phonePkg(CharSequence p) {
        if (p == null) return false;
        String s = p.toString();
        return s.contains("android.phone") || s.contains("telephony") || s.contains("telecom");
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent e) {
        try {
            int t = e.getEventType();
            if (t != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
                    && t != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) return;
            if (!phonePkg(e.getPackageName())) return;
            AccessibilityNodeInfo root = getRootInActiveWindow();
            if (root == null || !phonePkg(root.getPackageName())) return;

            Scan sc = new Scan();
            scan(root, sc);
            if (sc.buttons.isEmpty()) return;               // a USSD pop-up always has a button
            String text = sc.text.toString().trim();
            if (text.isEmpty() || RUNNING.matcher(text).find()) return;

            long now = SystemClock.uptimeMillis();
            if (text.equals(lastText) && now - lastAt < 2500) return;   // same pop-up, repeated event
            lastText = text;
            lastAt = now;

            Bridge.js("window.onUssdResponse(" + Bridge.q(text) + ")");
            if (!sc.input) {
                // Final message (no reply box): the page has been told, now close it.
                h.postDelayed(this::dismiss, 700);
            }
        } catch (Exception ignored) {
        }
    }

    private void scan(AccessibilityNodeInfo n, Scan sc) {
        if (n == null) return;
        CharSequence cn = n.getClassName();
        String c = cn == null ? "" : cn.toString();
        CharSequence tx = n.getText();
        if (c.contains("EditText")) {
            sc.input = true;
        } else if (c.contains("Button")) {
            sc.buttons.add(n);
        } else if (tx != null && tx.length() > 0) {
            if (sc.text.length() > 0) sc.text.append('\n');
            sc.text.append(tx);
        }
        for (int i = 0; i < n.getChildCount(); i++) scan(n.getChild(i), sc);
    }

    /** Type a reply into the USSD box and press Send. */
    void reply(String text) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) {
            Bridge.toast("No USSD window found to reply to");
            return;
        }
        AccessibilityNodeInfo in = findInput(root);
        if (in != null) {
            Bundle b = new Bundle();
            b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
            in.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b);
        }
        lastAt = SystemClock.uptimeMillis();   // ignore the old pop-up closing
        h.postDelayed(() -> {
            AccessibilityNodeInfo r = getRootInActiveWindow();
            if (r != null) press(r, SEND_BTN, true);
        }, 200);
    }

    /** Close the USSD pop-up (Cancel / OK). */
    void dismiss() {
        AccessibilityNodeInfo r = getRootInActiveWindow();
        if (r == null || !phonePkg(r.getPackageName())) return;
        lastAt = SystemClock.uptimeMillis();
        press(r, CLOSE_BTN, false);
    }

    private AccessibilityNodeInfo findInput(AccessibilityNodeInfo n) {
        if (n == null) return null;
        CharSequence cn = n.getClassName();
        if (cn != null && cn.toString().contains("EditText")) return n;
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo r = findInput(n.getChild(i));
            if (r != null) return r;
        }
        return null;
    }

    /** Click the button whose label matches; if none match (other languages), use the last (send) or first (cancel) button. */
    private void press(AccessibilityNodeInfo root, Pattern label, boolean lastIfNone) {
        Scan sc = new Scan();
        scan(root, sc);
        if (sc.buttons.isEmpty()) return;
        AccessibilityNodeInfo pick = null;
        for (AccessibilityNodeInfo b : sc.buttons) {
            CharSequence t = b.getText();
            if (t != null && label.matcher(t.toString().trim()).matches()) {
                pick = b;
                break;
            }
        }
        if (pick == null) pick = lastIfNone ? sc.buttons.get(sc.buttons.size() - 1) : sc.buttons.get(0);
        click(pick);
    }

    private void click(AccessibilityNodeInfo n) {
        AccessibilityNodeInfo x = n;
        while (x != null && !x.isClickable()) x = x.getParent();
        if (x == null) x = n;
        x.performAction(AccessibilityNodeInfo.ACTION_CLICK);
    }
}
